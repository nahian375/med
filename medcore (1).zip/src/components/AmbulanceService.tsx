import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { Button } from '../components/common/Button';
import { Truck, Search, Loader2, Phone, Navigation, ExternalLink, Sparkles, AlertCircle, Siren } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface Ambulance {
  name: string;
  contact: string;
  uri?: string;
}

export const AmbulanceService: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [ambulances, setAmbulances] = useState<Ambulance[]>([]);
  const [explanation, setExplanation] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const findNearbyAmbulances = async () => {
    setLoading(true);
    setError(null);
    setExplanation('');
    setAmbulances([]);
    
    try {
      const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        });
      });

      const { latitude, longitude } = pos.coords;

      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: "Find the 5 nearest ambulance services or emergency transport providers to my current location. List their names and contact numbers clearly.",
        config: {
          tools: [{ googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: { latitude, longitude }
            }
          }
        },
      });

      setExplanation(response.text || '');
      
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        const mapsChunks = chunks
          .filter((c: any) => c.maps)
          .map((c: any) => ({
            name: c.maps.title,
            contact: 'Contact via Maps', // Grounding might not always give phone directly in the chunk
            uri: c.maps.uri
          }));
        setAmbulances(mapsChunks);
      }

      if (!response.text && (!chunks || chunks.length === 0)) {
        setError('No nearby ambulance services found.');
      }
    } catch (err: any) {
      console.error(err);
      if (err.code === 1) {
        setError('Location permission denied. Please enable location access.');
      } else {
        setError('Failed to detect nearby ambulance services. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/50 border border-slate-100 overflow-hidden"
      >
        <div className="p-10 border-b border-slate-50 bg-gradient-to-br from-red-50/50 to-transparent">
          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-red-500 rounded-2xl text-white shadow-lg shadow-red-500/20">
              <Siren className="w-8 h-8" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-slate-900">Emergency Ambulance</h2>
              <p className="text-slate-500">Quick access to nearby emergency transport.</p>
            </div>
          </div>
          
          <div className="bg-white/50 p-8 rounded-[2rem] border border-white shadow-sm">
            <p className="text-slate-600 mb-8 text-lg">
              In case of emergency, use this tool to find the nearest ambulance services and their contact details.
            </p>
            <Button 
              onClick={findNearbyAmbulances} 
              disabled={loading}
              className="w-full sm:w-auto flex items-center justify-center gap-3 rounded-2xl px-10 py-6 bg-red-600 hover:bg-red-700 shadow-lg shadow-red-500/20 transition-all"
            >
              {loading ? <Loader2 className="w-6 h-6 animate-spin" /> : <Navigation className="w-6 h-6" />}
              <span className="text-lg font-bold">{loading ? 'Locating Services...' : 'Find Nearby Ambulances'}</span>
            </Button>
          </div>
        </div>

        <div className="p-10">
          <AnimatePresence mode="wait">
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-6 bg-red-50 border border-red-100 text-red-600 rounded-3xl mb-8 flex items-start gap-4"
              >
                <AlertCircle className="w-6 h-6 mt-0.5 flex-shrink-0" />
                <p className="font-medium">{error}</p>
              </motion.div>
            )}

            {(explanation || ambulances.length > 0) && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-10"
              >
                {explanation && (
                  <div className="prose prose-slate max-w-none bg-slate-50/50 p-10 rounded-[2.5rem] border border-slate-100 shadow-inner">
                    <ReactMarkdown>{explanation}</ReactMarkdown>
                  </div>
                )}

                {ambulances.length > 0 && (
                  <div className="space-y-6">
                    <div className="flex items-center gap-2 mb-4">
                      <Sparkles className="w-5 h-5 text-red-500" />
                      <h3 className="text-xl font-bold text-slate-900">Emergency Contacts</h3>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      {ambulances.map((ambulance, idx) => (
                        <motion.div 
                          key={idx}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.1 }}
                          className="p-8 border border-slate-100 rounded-[2rem] bg-white hover:shadow-2xl hover:-translate-y-1 hover:border-red-200 transition-all group relative overflow-hidden"
                        >
                          <div className="absolute top-0 right-0 w-24 h-24 bg-red-50 rounded-full -mr-12 -mt-12 opacity-0 group-hover:opacity-100 transition-opacity" />
                          <div className="relative z-10">
                            <div className="flex justify-between items-start mb-4">
                              <h4 className="text-xl font-bold text-slate-900 group-hover:text-red-600 transition-colors">{ambulance.name}</h4>
                              <div className="p-2 bg-red-50 rounded-xl text-red-500 opacity-0 group-hover:opacity-100 transition-all">
                                <Phone className="w-5 h-5" />
                              </div>
                            </div>
                            
                            <div className="mt-8 pt-6 border-t border-slate-100">
                              <a 
                                href={ambulance.uri}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-2 text-sm font-bold text-red-600 hover:text-red-700 bg-red-50 px-4 py-2 rounded-xl transition-colors"
                              >
                                <Navigation className="w-4 h-4" />
                                View on Google Maps
                              </a>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {!loading && ambulances.length === 0 && !explanation && !error && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-24 text-slate-400"
              >
                <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Truck className="w-12 h-12 opacity-10" />
                </div>
                <p className="text-xl font-medium">Emergency assistance ready.</p>
                <p className="text-slate-400 mt-2">Click the button above to find emergency transport near you.</p>
              </motion.div>
            )}

            {loading && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center py-24 text-slate-500"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-red-500/20 blur-3xl rounded-full animate-pulse"></div>
                  <Loader2 className="w-16 h-16 animate-spin text-red-600 relative z-10" />
                </div>
                <p className="mt-8 text-xl font-bold text-slate-900">Locating Emergency Services...</p>
                <p className="text-slate-500 mt-2 text-center max-w-sm">We're finding the fastest way to get you help.</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};
