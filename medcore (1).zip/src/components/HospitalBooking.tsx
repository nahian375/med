import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI } from "@google/genai";
import { Button } from '../components/common/Button';
import { Building2, Phone, Search, Loader2, MapPin, ExternalLink, CheckCircle2, Navigation, Sparkles, AlertCircle } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import api from '../services/api';

interface Hospital {
  id: number;
  name: string;
  location: string;
  contact: string;
  website: string;
  speciality: string;
  type: 'Public' | 'Private';
  availability_status: string;
}

export const HospitalBooking: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [nearbyHospitals, setNearbyHospitals] = useState<any[]>([]);
  const [explanation, setExplanation] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeType, setActiveType] = useState<'All' | 'Public' | 'Private' | 'Nearby'>('All');
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);

  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchHospitals(searchQuery, activeType);
  }, [activeType]);

  const fetchHospitals = async (query = '', type = activeType) => {
    if (type === 'Nearby') return; // Handled by handleNearbySearch
    
    setLoading(true);
    setError(null);
    try {
      const response = await api.get('/hospitals', { params: { query, type } });
      setHospitals(response.data);
    } catch (err) {
      setError('Failed to fetch hospitals');
    } finally {
      setLoading(false);
    }
  };

  const handleNearbySearch = async () => {
    setLoading(true);
    setError(null);
    setExplanation('');
    setNearbyHospitals([]);
    setActiveType('Nearby');
    
    try {
      const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        });
      });
      const { latitude, longitude } = pos.coords;
      setUserLocation({ lat: latitude, lng: longitude });

      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: "Find the 5 nearest hospitals or medical centers to my current location. List their names, addresses, and specialities.",
        config: {
          tools: [{ googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: { latitude, longitude }
            }
          }
        },
      });

      setExplanation(response.text || '');
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        const mapsChunks = chunks.filter((c: any) => c.maps).map((c: any) => c.maps);
        setNearbyHospitals(mapsChunks);
      }

      if (!response.text && (!chunks || chunks.length === 0)) {
        setError('No nearby hospitals available');
      }
    } catch (error) {
      console.error('Error getting location:', error);
      setError('Please enable location access to find nearby hospitals.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchHospitals(searchQuery, activeType);
  };

  return (
    <div className="max-w-5xl mx-auto p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-[2.5rem] shadow-xl shadow-slate-200/50 border border-slate-100 overflow-hidden"
      >
        <div className="p-10 border-b border-slate-50 bg-gradient-to-br from-blue-50/50 to-transparent">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-500 rounded-2xl text-white shadow-lg shadow-blue-500/20">
                <Building2 className="w-8 h-8" />
              </div>
              <div>
                <h2 className="text-3xl font-bold text-slate-900">Hospital Finder</h2>
                <p className="text-slate-500">Locate and visit healthcare facilities.</p>
              </div>
            </div>
            
            <div className="flex bg-slate-100 p-1.5 rounded-2xl overflow-x-auto no-scrollbar">
              {(['All', 'Public', 'Private', 'Nearby'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => type === 'Nearby' ? handleNearbySearch() : setActiveType(type)}
                  className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all whitespace-nowrap ${
                    activeType === type
                      ? 'bg-white text-blue-600 shadow-md'
                      : 'text-slate-500 hover:text-slate-700 hover:bg-white/50'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
          
          <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name, location, or speciality..."
                className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all text-lg"
              />
            </div>
            <Button type="submit" disabled={loading} className="rounded-2xl px-10 py-4 bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-500/20">
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Search'}
            </Button>
          </form>
        </div>

        <div className="p-10">
          <AnimatePresence mode="wait">
            {error && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-6 bg-red-50 border border-red-100 text-red-600 rounded-3xl mb-8 flex items-start gap-4"
              >
                <AlertCircle className="w-6 h-6 mt-0.5 flex-shrink-0" />
                <p className="font-medium">{error}</p>
              </motion.div>
            )}

            {activeType === 'Nearby' ? (
              <motion.div 
                key="nearby"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-10"
              >
                {explanation && (
                  <div className="prose prose-slate max-w-none bg-slate-50/50 p-10 rounded-[2.5rem] border border-slate-100 shadow-inner">
                    <ReactMarkdown>{explanation}</ReactMarkdown>
                  </div>
                )}
                
                {nearbyHospitals.length > 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {nearbyHospitals.map((hospital, idx) => (
                      <motion.div 
                        key={idx}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.1 }}
                        className="p-8 border border-slate-100 rounded-[2rem] bg-white hover:shadow-2xl hover:-translate-y-1 hover:border-blue-200 transition-all group relative overflow-hidden"
                      >
                        <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-full -mr-16 -mt-16 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <div className="relative z-10">
                          <div className="flex justify-between items-start mb-6">
                            <h3 className="text-2xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors">{hospital.title}</h3>
                            <div className="p-2 bg-blue-50 rounded-xl text-blue-500 opacity-0 group-hover:opacity-100 transition-all">
                              <ExternalLink className="w-5 h-5" />
                            </div>
                          </div>
                          <div className="mt-8 pt-6 border-t border-slate-100">
                            <a 
                              href={hospital.uri}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-2 text-sm font-bold text-blue-600 hover:text-blue-700 bg-blue-50 px-4 py-2 rounded-xl transition-colors"
                            >
                              <Navigation className="w-4 h-4" />
                              View on Google Maps
                            </a>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </motion.div>
            ) : (
              <motion.div 
                key="list"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-8"
              >
                {hospitals.map((hospital, idx) => (
                  <motion.div 
                    key={hospital.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    className="p-8 border border-slate-100 rounded-[2rem] bg-white hover:shadow-2xl hover:-translate-y-1 hover:border-blue-200 transition-all group"
                  >
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <div className="flex items-center gap-2 mb-3">
                          <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                            hospital.type === 'Public' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                          }`}>
                            {hospital.type}
                          </span>
                        </div>
                        <h3 className="text-2xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors">{hospital.name}</h3>
                      </div>
                    </div>
                    
                    <div className="space-y-4 mb-8">
                      <div className="flex items-center gap-3 text-slate-600">
                        <div className="p-2 bg-slate-50 rounded-lg group-hover:bg-blue-50 transition-colors">
                          <MapPin className="w-4 h-4 text-slate-400 group-hover:text-blue-500" />
                        </div>
                        <span className="text-sm font-medium">{hospital.location}</span>
                      </div>
                      <div className="flex items-center gap-3 text-slate-600">
                        <div className="p-2 bg-slate-50 rounded-lg group-hover:bg-blue-50 transition-colors">
                          <Phone className="w-4 h-4 text-slate-400 group-hover:text-blue-500" />
                        </div>
                        <span className="text-sm font-medium">{hospital.contact}</span>
                      </div>
                      <div className="flex items-start gap-3 text-slate-600">
                        <div className="p-2 bg-slate-50 rounded-lg group-hover:bg-blue-50 transition-colors">
                          <CheckCircle2 className="w-4 h-4 text-slate-400 group-hover:text-blue-500 mt-0.5" />
                        </div>
                        <span className="text-sm font-medium line-clamp-2">{hospital.speciality}</span>
                      </div>
                    </div>

                    {hospital.website && (
                      <a 
                        href={hospital.website} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="block"
                      >
                        <Button 
                          className="w-full rounded-2xl py-4 flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white shadow-lg transition-all"
                        >
                          Visit Booking Website
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      </a>
                    )}
                  </motion.div>
                ))}
              </motion.div>
            )}

            {((activeType !== 'Nearby' && hospitals.length === 0) || (activeType === 'Nearby' && nearbyHospitals.length === 0 && !explanation)) && !loading && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-24 text-slate-400"
              >
                <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Building2 className="w-12 h-12 opacity-10" />
                </div>
                <p className="text-xl font-medium">No hospitals found.</p>
                <p className="text-slate-400 mt-2">Try adjusting your search or filters.</p>
              </motion.div>
            )}

            {loading && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center py-24 text-slate-500"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-blue-500/20 blur-3xl rounded-full animate-pulse"></div>
                  <Loader2 className="w-16 h-16 animate-spin text-blue-600 relative z-10" />
                </div>
                <p className="mt-8 text-xl font-bold text-slate-900">Searching Hospitals...</p>
                <p className="text-slate-500 mt-2">We're finding the best healthcare facilities for you.</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};
