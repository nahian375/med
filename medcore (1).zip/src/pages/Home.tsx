import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../components/common/Button';
import { MedicalStoreLocator } from '../components/MedicalStoreLocator';
import { SymptomChecker } from '../components/SymptomChecker';
import { HospitalBooking } from '../components/HospitalBooking';
import { PrescriptionExplainer } from '../components/PrescriptionExplainer';
import { AmbulanceService } from '../components/AmbulanceService';
import { AboutMedCore } from '../components/AboutMedCore';
import { 
  ArrowLeft, 
  Stethoscope, 
  Building2, 
  Pill, 
  MapPin, 
  LayoutDashboard, 
  Settings, 
  User, 
  Bell,
  Search,
  ChevronRight,
  ShieldCheck,
  Siren
} from 'lucide-react';

type View = 'home' | 'stores' | 'symptoms' | 'booking' | 'explainer' | 'ambulance' | 'about';

export const Home: React.FC = () => {
  const [view, setView] = useState<View>('home');

  const renderContent = () => {
    switch (view) {
      case 'stores':
        return <MedicalStoreLocator />;
      case 'symptoms':
        return <SymptomChecker />;
      case 'booking':
        return <HospitalBooking />;
      case 'explainer':
        return <PrescriptionExplainer />;
      case 'ambulance':
        return <AmbulanceService />;
      case 'about':
        return <AboutMedCore />;
      default:
        return null;
    }
  };

  if (view !== 'home') {
    return (
      <div className="min-h-screen bg-[#F8F9FA]">
        <header className="sticky top-0 z-50 glass border-b border-slate-200/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <motion.button 
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setView('home')}
                className="p-2 hover:bg-slate-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-slate-600" />
              </motion.button>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-brand-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">M</span>
                </div>
                <h1 className="text-xl font-bold text-slate-900">MedCore</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm" className="rounded-xl">Help</Button>
              <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center overflow-hidden border-2 border-white shadow-sm">
                <User className="w-5 h-5 text-slate-500" />
              </div>
            </div>
          </div>
        </header>
        <motion.main 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="py-12"
        >
          {renderContent()}
        </motion.main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8F9FA] flex">
      {/* Sidebar - Desktop */}
      <aside className="hidden lg:flex flex-col w-72 bg-white border-r border-slate-200/50 p-6 sticky top-0 h-screen">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center shadow-lg shadow-brand-500/20">
            <span className="text-white font-bold text-lg">M</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900">MedCore</h1>
        </div>

        <nav className="flex-1 space-y-2">
          <SidebarItem icon={<LayoutDashboard />} label="Dashboard" active />
          <SidebarItem icon={<Bell />} label="Notifications" />
          <SidebarItem icon={<User />} label="My Profile" />
          <SidebarItem icon={<Settings />} label="Settings" />
        </nav>

        <div className="mt-auto p-4 bg-brand-50 rounded-2xl border border-brand-100">
          <div className="flex items-center gap-2 text-brand-700 font-semibold mb-1">
            <ShieldCheck className="w-4 h-4" />
            <span className="text-xs uppercase tracking-wider">Pro Plan</span>
          </div>
          <p className="text-xs text-brand-600 mb-3">Get unlimited AI checks and priority booking.</p>
          <Button size="sm" className="w-full rounded-xl bg-brand-600 hover:bg-brand-700">Upgrade</Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <header className="p-8 flex justify-between items-center">
          <div>
            <h2 className="text-3xl font-bold text-slate-900">Welcome to MedCore</h2>
            <p className="text-slate-500">Your health dashboard is up to date.</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search services..." 
                className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none w-64 transition-all"
              />
            </div>
            <button className="p-2 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors relative">
              <Bell className="w-5 h-5 text-slate-600" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
          </div>
        </header>

        <div className="px-8 pb-12">
          {/* Hero Section */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative h-[450px] rounded-[3rem] overflow-hidden mb-12 bg-slate-900 group shadow-2xl shadow-brand-500/10"
          >
            <img 
              src="https://picsum.photos/seed/medical-center/1600/900" 
              alt="Medical Center" 
              className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-1000"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/20 to-transparent p-16 flex flex-col justify-end">
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="max-w-2xl"
              >
                <h3 className="text-6xl font-bold text-white mb-6 leading-tight">Modern Healthcare, <br/><span className="text-brand-400">Simplified.</span></h3>
                <p className="text-xl text-slate-200 mb-8 leading-relaxed">
                  Experience a new era of medical assistance. From instant symptom analysis to emergency coordination, MedCore is your dedicated health partner.
                </p>
                <div className="flex gap-4">
                  <Button size="lg" className="rounded-2xl bg-brand-500 text-white hover:bg-brand-600 px-10 py-7 text-lg" onClick={() => setView('symptoms')}>
                    Start Health Check
                  </Button>
                  <Button 
                    size="lg" 
                    className="rounded-2xl bg-white/10 backdrop-blur-md text-white border border-white/20 hover:bg-white/20 px-10 py-7 text-lg"
                    onClick={() => setView('about')}
                  >
                    Learn More
                  </Button>
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Bento Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <BentoCard 
              icon={<Stethoscope className="w-8 h-8" />}
              title="Symptom Checker"
              description="Analyze your health concerns with our advanced AI diagnostic assistant."
              color="emerald"
              onClick={() => setView('symptoms')}
              delay={0.1}
              image="https://picsum.photos/seed/doctor/400/300"
            />
            <BentoCard 
              icon={<Building2 className="w-8 h-8" />}
              title="Hospital Finder"
              description="Locate the best healthcare facilities near you and visit their portals."
              color="blue"
              onClick={() => setView('booking')}
              delay={0.2}
              image="https://picsum.photos/seed/hospital/400/300"
            />
            <BentoCard 
              icon={<Pill className="w-8 h-8" />}
              title="AI Explainer"
              description="Upload prescriptions to understand your medication in simple terms."
              color="purple"
              onClick={() => setView('explainer')}
              delay={0.3}
              image="https://picsum.photos/seed/pills/400/300"
            />
            <BentoCard 
              icon={<MapPin className="w-8 h-8" />}
              title="Store Locator"
              description="Find pharmacies and medical stores near your current location instantly."
              color="orange"
              onClick={() => setView('stores')}
              delay={0.4}
              image="https://picsum.photos/seed/pharmacy/800/300"
            />
            <BentoCard 
              icon={<Siren className="w-8 h-8" />}
              title="Ambulance"
              description="Quickly find and contact emergency ambulance services in your vicinity."
              color="red"
              onClick={() => setView('ambulance')}
              delay={0.5}
              image="https://picsum.photos/seed/ambulance/400/300"
            />
            <div className="bento-card bg-brand-600 text-white flex flex-col justify-center items-center text-center p-12 relative overflow-hidden group">
              <div className="absolute inset-0 bg-brand-700 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="relative z-10">
                <h4 className="text-3xl font-bold mb-4">Need Help?</h4>
                <p className="text-brand-100 mb-8 text-lg">Our support team is available 24/7 for your health queries.</p>
                <Button className="bg-white text-brand-600 hover:bg-brand-50 rounded-2xl px-10 py-6 text-lg font-bold shadow-xl">Contact Us</Button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

const SidebarItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean }> = ({ icon, label, active }) => (
  <button className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all ${
    active 
      ? 'bg-brand-50 text-brand-600 font-semibold' 
      : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
  }`}>
    {React.isValidElement(icon) && React.cloneElement(icon as React.ReactElement<any>, { className: 'w-5 h-5' })}
    <span>{label}</span>
  </button>
);

const BentoCard: React.FC<{ 
  icon: React.ReactNode; 
  title: string; 
  description: string; 
  color: 'emerald' | 'blue' | 'purple' | 'orange' | 'red';
  onClick: () => void;
  delay: number;
  className?: string;
  image?: string;
}> = ({ icon, title, description, color, onClick, delay, className, image }) => {
  const colorMap = {
    emerald: 'bg-emerald-50 text-emerald-600 group-hover:bg-emerald-500 group-hover:text-white',
    blue: 'bg-blue-50 text-blue-600 group-hover:bg-blue-500 group-hover:text-white',
    purple: 'bg-purple-50 text-purple-600 group-hover:bg-purple-500 group-hover:text-white',
    orange: 'bg-orange-50 text-orange-600 group-hover:bg-orange-500 group-hover:text-white',
    red: 'bg-red-50 text-red-600 group-hover:bg-red-500 group-hover:text-white',
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      onClick={onClick}
      className={`bento-card group cursor-pointer relative overflow-hidden min-h-[320px] flex flex-col justify-end p-8 ${className}`}
    >
      {image && (
        <img 
          src={image} 
          alt={title} 
          className="absolute inset-0 w-full h-full object-cover opacity-10 group-hover:opacity-20 group-hover:scale-110 transition-all duration-700"
          referrerPolicy="no-referrer"
        />
      )}
      <div className="relative z-10">
        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-all duration-500 shadow-lg ${colorMap[color]}`}>
          {icon}
        </div>
        <h3 className="text-2xl font-bold text-slate-900 mb-2">{title}</h3>
        <p className="text-slate-500 leading-relaxed mb-6">{description}</p>
        <div className="flex items-center text-sm font-bold text-slate-900 group-hover:gap-2 transition-all">
          Explore Service
          <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-all" />
        </div>
      </div>
    </motion.div>
  );
};
