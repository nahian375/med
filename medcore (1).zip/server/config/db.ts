// Database configuration placeholder
// We will use better-sqlite3 for this environment
import Database from 'better-sqlite3';
import path from 'path';

const dbPath = path.resolve(process.cwd(), 'mediconnect.db');
const db = new Database(dbPath);

// Enable foreign keys
db.pragma('foreign_keys = ON');

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS hospitals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    location TEXT NOT NULL,
    contact TEXT NOT NULL,
    website TEXT,
    speciality TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'Private',
    availability_status TEXT DEFAULT 'Available',
    latitude REAL,
    longitude REAL
  );

  CREATE TABLE IF NOT EXISTS medical_stores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    contact TEXT NOT NULL,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL
  );
`);

// Seed sample data if empty
const hospitalCount = db.prepare('SELECT COUNT(*) as count FROM hospitals').get() as { count: number };
if (hospitalCount.count === 0) {
  const insert = db.prepare('INSERT INTO hospitals (name, location, contact, website, speciality, type, availability_status, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
  const sampleHospitals = [
    // Public Hospitals
    ['Dhaka Medical College Hospital', 'Bakshibazar, Dhaka', '01715016984', 'http://dmc.gov.bd', 'Multispecialty, Government', 'Public', 'Available', 23.7258, 90.3973],
    ['Dhaka Leprosy Hospital', 'Dhaka', 'dlh@hospi.dghs.gov.bd', null, 'Leprosy Care, Government', 'Public', 'Available', 23.8103, 90.4125],
    ['Govt Homeopathic Medical College Hospital', 'Dhaka', 'dhdc@ac.dghs.gov.bd', null, 'Homeopathic Treatment, Government', 'Public', 'Available', 23.7500, 90.3800],
    ['Bangabandhu Sheikh Mujib Medical University (BSMMU)', 'Shahbag, Dhaka', '02-55165760', 'https://bsmmu.ac.bd', 'Multispecialty, Research, Postgraduate', 'Public', 'Available', 23.7391, 90.3958],
    ['BIRDEM General Hospital', 'Shahbag, Dhaka', '02-41050171', 'https://www.birdem.org.bd', 'Diabetes, Endocrinology, General Medicine', 'Public', 'Available', 23.7385, 90.3955],
    ['Kurmitola General Hospital', 'Cantonment, Dhaka', '0255062388', 'https://kgh.gov.bd', 'Multispecialty, Government', 'Public', 'Available', 23.8210, 90.4130],
    ['Shaheed Suhrawardy Hospital', 'Sher-e-Bangla Nagar, Dhaka', '02-9130800', null, 'Multispecialty, Government', 'Public', 'Available', 23.7695, 90.3715],
    ['Ad-Din Hospital', 'Moghbazar, Dhaka', '02-9353391', 'https://ad-din.org', 'Multispecialty, Public Listed', 'Public', 'Available', 23.7485, 90.4035],
    ['Sher-e-Bangla Medical College Hospital', 'Barisal', '0431-2173500', null, 'Multispecialty, Government', 'Public', 'Available', 22.6860, 90.3600],
    ['Rajshahi Medical College Hospital', 'Rajshahi', '0721-772150', null, 'Multispecialty, Government', 'Public', 'Available', 24.3700, 88.5800],
    ['Rangpur Medical College Hospital', 'Rangpur', '0521-62150', null, 'Multispecialty, Government', 'Public', 'Available', 25.7500, 89.2500],
    ['Mugda Medical College & Hospital', 'Mugda, Dhaka', '02-7272845', null, 'Multispecialty, Government', 'Public', 'Available', 23.7295, 90.4315],
    ['Sylhet MAG Osmani Medical College & Hospital', 'Sylhet', '0821-713667', null, 'Multispecialty, Government', 'Public', 'Available', 24.9000, 91.8600],
    ['Chittagong Medical College Hospital', 'Chittagong', '031-619400', null, 'Multispecialty, Government', 'Public', 'Available', 22.3500, 91.8300],
    ['Mymensingh Medical College Hospital', 'Mymensingh', '091-66063', null, 'Multispecialty, Government', 'Public', 'Available', 24.7500, 90.4000],
    ['Khwaja Yunus Ali Medical College & Hospital', 'Enayetpur, Sirajganj', '0751-64277', 'https://www.kyamch.org', 'Multispecialty, Semi-Govt', 'Public', 'Available', 24.2200, 89.7000],
    ['Institute of Child and Mother Health (ICMH)', 'Matuail, Dhaka', '02-7542692', 'https://icmh.org.bd', 'Maternal & Child Care, Government', 'Public', 'Available', 23.7000, 90.4700],
    ['National Institute of Cardiovascular Diseases', 'Sher-e-Bangla Nagar, Dhaka', '02-9122560', null, 'Specialized Heart Care, Government', 'Public', 'Available', 23.7700, 90.3700],
    ['National Institute of Mental Health and Hospital', 'Sher-e-Bangla Nagar, Dhaka', '02-9118171', null, 'Mental Health Services, Government', 'Public', 'Available', 23.7710, 90.3710],
    ['Centre for Rehabilitation of the Paralysed (CRP)', 'Savar, Dhaka', '02-7745464', 'https://crp-bangladesh.org', 'Rehabilitation, Govt-NGO', 'Public', 'Available', 23.8900, 90.2500],

    // Private Hospitals
    ['Evercare Hospital Dhaka', 'Bashundhara R/A, Dhaka', '+8809666710678', 'https://www.evercarebd.com', 'Multispecialty, Cardiology, Oncology', 'Private', 'Available', 23.8100, 90.4300],
    ['United Hospital Limited', 'Gulshan, Dhaka', '+8801914001234', 'https://www.uhlbd.com', 'Multispecialty, Cardiology, Nephrology', 'Private', 'Available', 23.7900, 90.4100],
    ['Square Hospitals Ltd.', 'West Panthapath, Dhaka', '+88028144400', 'https://www.squarehospital.com', 'Multispecialty, Surgery, Internal Medicine', 'Private', 'Available', 23.7500, 90.3800],
    ['Bangladesh Specialized Hospital Ltd.', 'Shyamoli, Dhaka', '09666-710606', 'https://www.bshl.com.bd', 'Multispecialty', 'Private', 'Available', 23.7700, 90.3600],
    ['Labaid Specialized Hospital', 'Dhanmondi, Dhaka', '10606', 'https://labaidgroup.com', 'Multispecialty, Cardiology, Gastroenterology', 'Private', 'Available', 23.7400, 90.3800],
    ['Ibn Sina Hospital Sylhet Ltd.', 'Sylhet', '0821-728645', 'https://www.ibnsinatrust.com', 'Multispecialty', 'Private', 'Available', 24.8900, 91.8700],
    ['Ibn Sina Hospitals', 'Dhaka', '10615', 'https://www.ibnsinatrust.com', 'Multispecialty', 'Private', 'Available', 23.7500, 90.3700],
    ['Greenland Hospital Ltd.', 'Uttara, Dhaka', '02-8932374', null, 'Multispecialty', 'Private', 'Available', 23.8700, 90.4000],
    ['Medinova Medical Services Ltd.', 'Dhaka', '02-9676611', 'https://medinova.com.bd', 'Diagnostic, Multispecialty', 'Private', 'Available', 23.7400, 90.3700],
    ['Gazi Medical College Hospital', 'Khulna', '041-763585', 'http://gmch.edu.bd', 'Multispecialty', 'Private', 'Available', 22.8200, 89.5500],
    ['Oasis Hospital (Pvt) Ltd.', 'Sylhet', '0821-713344', 'https://oasishospitalbd.com', 'Multispecialty', 'Private', 'Available', 24.9000, 91.8500],
    ['Royal Hospital & Research Center Ltd.', 'Chittagong', '031-652533', null, 'Multispecialty', 'Private', 'Available', 22.3600, 91.8200],
    ['Popular Specialized Hospital Ltd.', 'Dhanmondi, Dhaka', '09613-787801', 'https://popular-diagnostic.com', 'Multispecialty', 'Private', 'Available', 23.7400, 90.3800],
    ['Insaf Barakah Kidney & General Hospital', 'Moghbazar, Dhaka', '02-9350850', 'https://insafbarakah.com', 'Kidney & General Health', 'Private', 'Available', 23.7500, 90.4000],
    ['Medifair General Hospital', 'Dhaka (North)', 'maccamadinaghospital@gmail.com', null, 'Multispecialty', 'Private', 'Available', 23.8000, 90.4000],
    ['Shareef General Hospital Pvt. Ltd.', 'Gazipur', 'shareefgh@hotmail.net', null, 'Multispecialty', 'Private', 'Available', 23.9900, 90.4100],
    ['Life Aid Hospital', 'Thakurgaon', 'lifeaidh2015@gmail.com', null, 'Multispecialty', 'Private', 'Available', 26.0300, 88.4600],
    ['CDM Hospital', 'Rajshahi', '0721-773384', null, 'Multispecialty', 'Private', 'Available', 24.3700, 88.6000],
    ['Health Care Hospital', 'Sirajganj', '0751-64277', null, 'Multispecialty', 'Private', 'Available', 24.4500, 89.7000],
    ['Remedy Hospital & Diagnostic Centre', 'Savar, Dhaka', 'remedyhospital2019@gmail.com', null, 'Multispecialty', 'Private', 'Available', 23.8500, 90.2600],
    ['New Kotalipara Surgical Clinic', 'Gopalganj', '02-6656123', null, 'Surgical Clinic', 'Private', 'Available', 23.0000, 89.8200],
    ['Prime Hospital & Diagnostic Center', 'Khulna', '041-723456', null, 'Multispecialty', 'Private', 'Available', 22.8100, 89.5600],
    ['Shimantik Hospital & Training Institute', 'Sylhet', '0821-712345', null, 'Multispecialty', 'Private', 'Available', 24.8800, 91.8800],
    ['VARD Eye Hospital', 'Sunamganj', '0871-61234', null, 'Eye Hospital', 'Private', 'Available', 25.0600, 91.4000],
    ['Harun General Hospital (Pvt.) Ltd', 'Dhanmondi, Dhaka', '02-9661234', null, 'Multispecialty', 'Private', 'Available', 23.7400, 90.3800],
    ['Prime General Hospital', 'Narsingdi', 'primegeneralhospital737599@gmail.com', null, 'Multispecialty', 'Private', 'Available', 23.9200, 90.7200],
    ['Prime Hospital', 'Tangail', '0921-61234', null, 'Multispecialty', 'Private', 'Available', 24.2500, 89.9200],
    ['Goshairhat Adhunik Hospital', 'Shariatpur', '0601-61234', null, 'Multispecialty', 'Private', 'Available', 23.2000, 90.3500],
    ['Padma General Hospital & Diagnostic Centre', 'Dhaka', '02-9112345', null, 'Multispecialty', 'Private', 'Available', 23.7500, 90.3900],
    ['Moulvibazar Adhunik Eye Hospital', 'Moulvibazar', '0861-61234', null, 'Eye Hospital', 'Private', 'Available', 24.4800, 91.7700],
    ['Aslam Diagnostic Center', 'Dhaka', '02-8112345', null, 'Diagnostic', 'Private', 'Available', 23.7500, 90.3800],
    ['CB Diagnostic', 'Dhaka', '02-7112345', null, 'Diagnostic', 'Private', 'Available', 23.7300, 90.4100],
    ['Bolaka Digital Diagnostic Center', 'Dhaka', '02-6112345', null, 'Diagnostic', 'Private', 'Available', 23.7400, 90.4000],
    ['Medinet Medical Services', 'Dhaka', '02-5112345', null, 'Multispecialty', 'Private', 'Available', 23.7500, 90.3700],
    ['Maa Diagnostic Centre', 'Dhaka', '02-4112345', null, 'Diagnostic', 'Private', 'Available', 23.7600, 90.3800],
    ['Birampur Diagnostic Center', 'Dinajpur', '0531-61234', null, 'Diagnostic', 'Private', 'Available', 25.4500, 88.9500],
    ['Plasma Diagnostic Center', 'Dhaka', '02-3112345', null, 'Diagnostic', 'Private', 'Available', 23.7700, 90.3900],
    ['New Dhakadakshin Diagnostic Centre', 'Sylhet', '0821-61234', null, 'Diagnostic', 'Private', 'Available', 24.8500, 91.9500],
    ['K I Digital Hospital & Diagnostic Center', 'Dhaka', '02-2112345', null, 'Multispecialty', 'Private', 'Available', 23.7800, 90.4000],
    ['Seba Diagnostic Center', 'Dhaka', '02-1112345', null, 'Diagnostic', 'Private', 'Available', 23.7900, 90.4100],
    ['Padma Digital Diagnostic Center', 'Dhaka', '02-0112345', null, 'Diagnostic', 'Private', 'Available', 23.8000, 90.4200],
    ['EW VM Health Bangladesh Ltd', 'Dhaka', '02-9112345', null, 'Multispecialty', 'Private', 'Available', 23.8100, 90.4300]
  ];
  
  for (const h of sampleHospitals) {
    insert.run(...h);
  }
}

// Seed medical stores
const storeCount = db.prepare('SELECT COUNT(*) as count FROM medical_stores').get() as { count: number };
if (storeCount.count === 0) {
  const insertStore = db.prepare('INSERT INTO medical_stores (name, address, contact, latitude, longitude) VALUES (?, ?, ?, ?, ?)');
  const sampleStores = [
    ['Lazz Pharma (Panthapath)', 'Panthapath, Dhaka', '01711-123456', 23.7510, 90.3850],
    ['Tamanna Pharmacy', 'Dhanmondi, Dhaka', '01811-234567', 23.7450, 90.3750],
    ['Khidmah Pharma', 'Khilgaon, Dhaka', '01911-345678', 23.7550, 90.4250],
    ['Model Pharmacy', 'Gulshan, Dhaka', '01611-456789', 23.7950, 90.4150],
    ['Dhaka Pharma', 'Uttara, Dhaka', '01511-567890', 23.8750, 90.4050],
    ['Blue Pharma', 'Mirpur, Dhaka', '01311-678901', 23.8050, 90.3650],
    ['Green Pharma', 'Mohammadpur, Dhaka', '01411-789012', 23.7650, 90.3550],
    ['City Pharma', 'Moghbazar, Dhaka', '01722-123456', 23.7500, 90.4000],
    ['Care Pharma', 'Banani, Dhaka', '01822-234567', 23.7900, 90.4000],
    ['Health Pharma', 'Badda, Dhaka', '01922-345678', 23.7800, 90.4300]
  ];

  for (const s of sampleStores) {
    insertStore.run(...s);
  }
}

export default db;
